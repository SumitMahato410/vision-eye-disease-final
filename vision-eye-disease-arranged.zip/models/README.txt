Put the trained model files used for inference in this folder.
Do not put the full training dataset here.
