# Vision Eye Disease - Arranged Structure

This folder is arranged for a Flask/Vercel project.

IMPORTANT:
The source repository contents should be copied into the corresponding
src/, templates/, and training/ locations. The placeholder files in this
package are NOT replacements for the original source code.

Structure:

vision-eye-disease/
├── app.py
├── vercel.json
├── requirements.txt
├── requirements-train.txt
├── Procfile
├── Dockerfile
├── templates/
│   └── index.html
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── data.py
│   ├── inference.py
│   ├── models.py
│   ├── gradcam.py
│   └── advice.py
├── training/
│   ├── train.py
│   ├── evaluate.py
│   ├── prepare_odir.py
│   ├── split_dataset.py
│   └── smoke_test.py
└── models/
    └── trained model files
