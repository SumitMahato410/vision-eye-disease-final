from flask import Flask, render_template, request, jsonify
from src import config as cfg
from src import inference

app = Flask(__name__, template_folder="templates")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

# Keep your existing prediction endpoint/inference logic here if it differs.
@app.route("/predict", methods=["POST"])
def predict():
    return inference.predict(request)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
