# Move your original smoke_test.py here.
